import { renderTopNav } from "./index/topNav.js";
import {renderCrudMenu} from "./index/crudMenu.js";
import { renderBorrowedBooks } from "../data/books.js";
renderTopNav();
renderBorrowedBooks();
renderCrudMenu();